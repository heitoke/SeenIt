import { createError } from 'h3';
import mongoose from 'mongoose';

// * Types
import { makeCode } from '../../../../../types/db';
import { LogCode } from '~~/types/db/log';


interface Body {
    action: 'accept' | 'reject';
}


export default defineEventHandler(async (event) => {
    const $user = await $userAuth.require(event);

    const logId = await getRouterParam(event, 'logId');

    const { action } = await readBody(event) as Body;

    const notifyLog = await LogSchema
        .findOne({
            _id: { $in: String(logId) },
            user: { $in: String($user?._id) },
            code: { $bitsAllSet: makeCode(0, 2) }
        } as any);

    if (!notifyLog) {
        throw createError({
            statusCode: 404,
            statusMessage: 'Not found notify by id!'
        });
    }

    if (notifyLog.code === LogCode.List.InvitedMember) {
        const res = await $fetch<any>(`http://${notifyLog?.props?.host}/api/members`, {
            body: JSON.stringify({
                action: 'list:invited',
                userId: notifyLog?.props?.inviter?._id,
                code: notifyLog?.props?.code,
                result: action
            }),
            method: 'PUT'
        });

        if (!res?.success) return;

        notifyLog.code = LogCode.List[res?.result === 'accept' ? 'InvitedMemberAccept' : 'InvitedMemberReject'];

        await notifyLog.save();

        return {
            success: true
        }
    }

    return null;
});
