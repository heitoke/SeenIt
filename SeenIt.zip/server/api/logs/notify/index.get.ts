import { createError } from 'h3';
import mongoose from 'mongoose';

// * Types
import { makeCode } from '../../../../types/db';
import { LogCode } from '~~/types/db/log';


export default defineEventHandler(async (event) => {
    const $user = await $userAuth.require(event);

    const notifyLogs = await LogSchema
        .find({
            user: { $in: String($user?._id) },
            code: { $bitsAllSet: makeCode(0, 2) }
        } as any)
        .select('-user -__v -props.code')
        .lean();

    return notifyLogs;
});
