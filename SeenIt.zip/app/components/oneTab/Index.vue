<template>
    <div class="one-tab">
        <iframe ref="iframe" :src="authIFrameUrl"
            @load="onIFrameLoad"
        />
    </div>
</template>

<script lang="ts" setup>

const $onaTab = useOneTabStore();

const authDomain = 'http://127.0.0.1:7433'; // 'https://seen-it.vercel.app';
const authIFrameUrl = authDomain + '/one-tab';

const iframe = ref<HTMLIFrameElement | null>(null);


const sendMessage = (type: string, data: Record<string, any> = {}) => {
    if (!iframe.value?.contentWindow) return false;

    iframe.value.contentWindow?.postMessage({
        type,
        data
    }, authDomain);
}

async function handleIFrameMessage(event: MessageEvent<{ type: string, data: Record<string, any> }>) {
    if (event.origin !== authDomain) return;

    const { type, data } = event.data;

    if (type === 'logins:get') {
        console.log(type, data)
    }
}

function onIFrameLoad() {
    sendMessage('logins:get');
}


onMounted(() => {
    $onaTab.emitter.on('auth:user', ({ user }) => {
        if (!user?._id) return;

        sendMessage('auth:user', {
            host: location.host,
            user
        });
    });

    window.addEventListener('message', handleIFrameMessage);
});

onUnmounted(() => {
    window.removeEventListener('message', handleIFrameMessage);
});

</script>

<style lang="scss" scoped>

.one-tab {
    position: fixed;
    top: 64px;
    right: 12px;
    border-radius: var(--hx-border-radius);
    border: 1px dashed var(--hx-background-transparent);
    background-color: var(--hx-background-primary);
    overflow: hidden;
    z-index: 99999999999;

    iframe {
        border: none;
    }
}

</style>