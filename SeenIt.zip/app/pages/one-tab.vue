<template>
    <div class="one-tab">
        <div class="user" v-if="user?._id">
            <!-- <Image :src="getUrlAvatar(user?._id)"/> -->

            <div>
                <div>@{{ user?.username }}</div>
                <div>{{ $request.host }}</div>
            </div>
        </div>
        <header>
        </header>
        <Button>{{ user?.username }}</Button>
    </div>
</template>

<script lang="ts" setup>

import Image from '~/components/ui/Image.vue';

const { user, me } = useUserAuth();


const $request = useRequestURL();

const t = ref<Array<any>>([]);


async function handleMessage(event: MessageEvent<{ type: string, data: Record<string, any> }>) {
    const { type, data } = event.data;

    if (type === 'logins:get') {
        event.source?.postMessage({
            type,
            data: {
                user: {
                    ...user.value
                }
            }
        }, event.origin as any);
    }

    if (type === 'auth:user') {
        t.value.push([type, data])
        // event.source?.postMessage({
        //     type,
        //     data: {
        //         user
        //     }
        // }, event.origin as any);
    }
}

onMounted(() => {
    window.addEventListener('message', handleMessage);
    
    if (window.parent !== window) {
        window.parent.postMessage('ready', '*');
    }
});

onUnmounted(() => {
    window.removeEventListener('message', handleMessage);
});

</script>

<style lang="scss" scoped>

.page.one-tab {
    margin: 0;
    padding: 12px;
    box-sizing: border-box;
    overflow: hidden;
}

</style>