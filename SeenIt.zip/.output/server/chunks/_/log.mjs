import { m as makeCode } from './index.mjs';

var ListLogCode = ((ListLogCode2) => {
  ListLogCode2[ListLogCode2["Update"] = makeCode(2, 1, 1)] = "Update";
  ListLogCode2[ListLogCode2["Delete"] = makeCode(2, 1, 2)] = "Delete";
  ListLogCode2[ListLogCode2["InviteMember"] = makeCode(2, 2, 1)] = "InviteMember";
  ListLogCode2[ListLogCode2["InviteMemberAccept"] = makeCode(2, 1, 1, 1)] = "InviteMemberAccept";
  ListLogCode2[ListLogCode2["InviteMemberReject"] = makeCode(2, 1, 1, 2)] = "InviteMemberReject";
  ListLogCode2[ListLogCode2["InvitedMember"] = makeCode(2, 2, 2)] = "InvitedMember";
  ListLogCode2[ListLogCode2["InvitedMemberAccept"] = makeCode(2, 1, 2, 1)] = "InvitedMemberAccept";
  ListLogCode2[ListLogCode2["InvitedMemberReject"] = makeCode(2, 1, 2, 2)] = "InvitedMemberReject";
  return ListLogCode2;
})(ListLogCode || {});

var CategoryLogCode = ((CategoryLogCode2) => {
  CategoryLogCode2[CategoryLogCode2["Update"] = makeCode(3, 1, 1)] = "Update";
  CategoryLogCode2[CategoryLogCode2["Delete"] = makeCode(3, 1, 2)] = "Delete";
  return CategoryLogCode2;
})(CategoryLogCode || {});

var TitleLogCode = ((TitleLogCode2) => {
  TitleLogCode2[TitleLogCode2["MoveToCategory"] = makeCode(4, 1, 1)] = "MoveToCategory";
  TitleLogCode2[TitleLogCode2["Like"] = makeCode(4, 1, 2)] = "Like";
  TitleLogCode2[TitleLogCode2["Private"] = makeCode(4, 1, 3)] = "Private";
  TitleLogCode2[TitleLogCode2["Delete"] = makeCode(4, 1, 4)] = "Delete";
  return TitleLogCode2;
})(TitleLogCode || {});

const LogCode = {
  List: ListLogCode,
  Category: CategoryLogCode,
  Title: TitleLogCode};

export { LogCode as L };
//# sourceMappingURL=log.mjs.map
