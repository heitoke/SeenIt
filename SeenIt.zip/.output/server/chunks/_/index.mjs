function makeCode(type = 0, subtype = 0, action = 0, extra = 0) {
  const typeMasked = type & 4095;
  const subtypeMasked = subtype & 15;
  const actionMasked = action & 4095;
  const extraMasked = extra & 15;
  return (typeMasked << 20 | subtypeMasked << 16 | actionMasked << 12 | extraMasked) >>> 0;
}

export { makeCode as m };
//# sourceMappingURL=index.mjs.map
