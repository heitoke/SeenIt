import { c as defineEventHandler, $ as $userAuth, r as readBody, C as CategorySchema, e as createError, h as createLogs, T as TitleSchema, L as LogObjectId } from '../../_/nitro.mjs';
import { L as LogCode } from '../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../_/index.mjs';

const index_delete = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const { ids } = await readBody(event);
  let categories = await CategorySchema.find({
    _id: { $in: ids.map(String) }
  }).populate("list").lean();
  categories = categories.filter((category) => {
    var _a;
    return String((_a = category.list) == null ? void 0 : _a.user) === String($user._id);
  });
  if ((categories == null ? void 0 : categories.length) < 1) {
    throw createError({
      statusCode: 404,
      statusMessage: "Couldn't find at least one category"
    });
  }
  const categoryIds = categories.map((r) => String(r._id));
  await CategorySchema.deleteMany({
    _id: { $in: categoryIds }
  });
  createLogs(String($user._id), LogCode.Category.Delete, categories, ({ list, ...category }) => {
    if (!categoryIds.includes(String(category._id))) return null;
    return {
      category: new LogObjectId(category._id),
      deletedData: {
        ...category,
        list: list == null ? void 0 : list._id
      }
    };
  });
  const titles = await TitleSchema.find({
    category: { $in: categoryIds }
  }).lean();
  const titleIds = titles.map((title) => String(title._id));
  await TitleSchema.deleteMany({
    _id: { $in: titleIds }
  });
  createLogs(String($user._id), LogCode.Title.Delete, titles, ({ category, ...title }) => {
    if (!titleIds.includes(String(title._id))) return null;
    return {
      title: new LogObjectId(title._id),
      deletedData: {
        ...title,
        category: new LogObjectId(category == null ? void 0 : category._id)
      }
    };
  });
  return {
    success: true,
    deletedCategories: categoryIds,
    deletedTitles: titleIds
  };
});

export { index_delete as default };
//# sourceMappingURL=index.delete.mjs.map
