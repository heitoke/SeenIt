import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, T as TitleSchema, e as createError } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const $user = await $userAuth.getUser(event);
  const titleId = getRouterParam(event, "titleId");
  const title = await TitleSchema.findOne({ _id: String(titleId) }).populate("tmdbTitle").populate([
    {
      path: "category",
      select: ["-__v"],
      populate: {
        path: "list",
        select: ["-__v"],
        populate: {
          path: "user",
          select: ["-password"]
        }
      }
    },
    {
      path: "tmdbTitle"
    }
  ]).select(["-__v"]).lean({ virtuals: true });
  if (Boolean(title == null ? void 0 : title.private) && String((_c = (_b = (_a = title == null ? void 0 : title.category) == null ? void 0 : _a.list) == null ? void 0 : _b.user) == null ? void 0 : _c._id) !== String($user == null ? void 0 : $user._id)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found title by id"
    });
  }
  title["data"] = {
    ...(_d = title == null ? void 0 : title.tmdbTitle) == null ? void 0 : _d.data,
    mediaType: (_e = title == null ? void 0 : title.tmdbTitle) == null ? void 0 : _e.mediaType
  };
  delete title["tmdbTitle"];
  return title;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
