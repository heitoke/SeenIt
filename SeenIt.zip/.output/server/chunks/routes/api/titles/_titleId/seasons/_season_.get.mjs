import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, T as TitleSchema, e as createError, u as useRuntimeConfig } from '../../../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const _season__get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const $user = await $userAuth.getUser(event);
  const titleId = getRouterParam(event, "titleId");
  const seasonNumber = getRouterParam(event, "season");
  const title = await TitleSchema.findOne({ _id: String(titleId) }).populate([
    {
      path: "category",
      select: ["-__v"],
      populate: {
        path: "list",
        select: ["-__v"],
        populate: {
          path: "user",
          select: ["-password"]
        }
      }
    },
    {
      path: "tmdbTitle",
      match: { mediaType: 1 }
    }
  ]).select(["-__v"]).lean({ virtuals: true });
  if (!(title == null ? void 0 : title.tmdbTitle) || Boolean(title == null ? void 0 : title.private) && String((_c = (_b = (_a = title == null ? void 0 : title.category) == null ? void 0 : _a.list) == null ? void 0 : _b.user) == null ? void 0 : _c._id) !== String($user == null ? void 0 : $user._id)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found title by id"
    });
  }
  const config = useRuntimeConfig(event);
  const { tmdbId } = title == null ? void 0 : title.tmdbTitle;
  const res = await fetch(`${config.tmdbApiUrl}/tv/${tmdbId}/season/${seasonNumber}`, {
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${config.tmdbApiKey}`
    },
    method: "GET"
  });
  console.log(res);
  if (!res.ok) {
    throw createError({
      statusCode: 500,
      statusMessage: "Error server"
    });
  }
  const json = await res.json();
  return json;
});

export { _season__get as default };
//# sourceMappingURL=_season_.get.mjs.map
