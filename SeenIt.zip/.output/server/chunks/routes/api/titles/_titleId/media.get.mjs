import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, T as TitleSchema, e as createError, u as useRuntimeConfig } from '../../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const media_get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const $user = await $userAuth.getUser(event);
  const titleId = getRouterParam(event, "titleId");
  const title = await TitleSchema.findOne({ _id: String(titleId) }).populate("tmdbTitle").populate([
    {
      path: "category",
      select: ["-__v"],
      populate: {
        path: "list",
        select: ["-__v"],
        populate: {
          path: "user",
          select: ["-password"]
        }
      }
    },
    {
      path: "tmdbTitle"
    }
  ]).select(["-__v"]).lean({ virtuals: true });
  if (Boolean(title == null ? void 0 : title.private) && String((_c = (_b = (_a = title == null ? void 0 : title.category) == null ? void 0 : _a.list) == null ? void 0 : _b.user) == null ? void 0 : _c._id) !== String($user == null ? void 0 : $user._id)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found title by id"
    });
  }
  const config = useRuntimeConfig(event);
  const { tmdbId, mediaType } = title == null ? void 0 : title.tmdbTitle;
  const tmdbTitleUrlMediaTemplate = `${config.tmdbApiUrl}/${mediaType === 0 ? "movie" : "tv"}/${tmdbId}`;
  const [dataImages, dataVideos] = await Promise.all([
    tmdbTitleUrlMediaTemplate + "/images",
    tmdbTitleUrlMediaTemplate + "/videos"
  ].map((url) => fetch(url, {
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${config.tmdbApiKey}`
    },
    method: "GET"
  }).then((res) => {
    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`);
    }
    return res.json();
  })));
  return {
    logos: (dataImages == null ? void 0 : dataImages.logos) || [],
    posters: (dataImages == null ? void 0 : dataImages.posters) || [],
    backdrops: (dataImages == null ? void 0 : dataImages.backdrops) || [],
    videos: (dataVideos == null ? void 0 : dataVideos.results) || []
  };
});

export { media_get as default };
//# sourceMappingURL=media.get.mjs.map
