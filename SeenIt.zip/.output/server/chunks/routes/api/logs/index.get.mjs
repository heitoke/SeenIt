import { c as defineEventHandler, $ as $userAuth, j as LogSchema } from '../../../_/nitro.mjs';
import { m as makeCode } from '../../../_/index.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_get = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const notifyLogs = await LogSchema.find({
    user: { $in: String($user == null ? void 0 : $user._id) },
    code: { $bitsAllSet: makeCode(0, 2) }
  }).select("-user -__v -props.code").lean();
  return notifyLogs;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
