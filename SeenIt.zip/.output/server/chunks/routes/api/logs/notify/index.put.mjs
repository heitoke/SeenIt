import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, r as readBody, j as LogSchema, e as createError } from '../../../../_/nitro.mjs';
import { m as makeCode } from '../../../../_/index.mjs';
import { L as LogCode } from '../../../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const $user = await $userAuth.require(event);
  const logId = await getRouterParam(event, "logId");
  const { action } = await readBody(event);
  const notifyLog = await LogSchema.findOne({
    _id: { $in: String(logId) },
    user: { $in: String($user == null ? void 0 : $user._id) },
    code: { $bitsAllSet: makeCode(0, 2) }
  });
  if (!notifyLog) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found notify by id!"
    });
  }
  if (notifyLog.code === LogCode.List.InvitedMember) {
    const res = await $fetch(`http://${(_a = notifyLog == null ? void 0 : notifyLog.props) == null ? void 0 : _a.host}/api/members`, {
      body: JSON.stringify({
        action: "list:invited",
        userId: (_c = (_b = notifyLog == null ? void 0 : notifyLog.props) == null ? void 0 : _b.inviter) == null ? void 0 : _c._id,
        code: (_d = notifyLog == null ? void 0 : notifyLog.props) == null ? void 0 : _d.code,
        result: action
      }),
      method: "PUT"
    });
    if (!(res == null ? void 0 : res.success)) return;
    notifyLog.code = LogCode.List[(res == null ? void 0 : res.result) === "accept" ? "InvitedMemberAccept" : "InvitedMemberReject"];
    await notifyLog.save();
    return {
      success: true
    };
  }
  return null;
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
