import { c as defineEventHandler, $ as $userAuth, i as ListSchema } from '../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_get = defineEventHandler(async (event) => {
  const payload = await $userAuth.require(event);
  const lists = await ListSchema.find({ userId: payload._id });
  return lists;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
