import { c as defineEventHandler, $ as $userAuth, r as readBody, T as TitleSchema, e as createError, h as createLogs, L as LogObjectId } from '../../_/nitro.mjs';
import { L as LogCode } from '../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../_/index.mjs';

const index_delete = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const { ids } = await readBody(event);
  let titles = await TitleSchema.find({
    _id: { $in: ids.map(String) }
  }).populate({
    path: "category",
    populate: {
      path: "list"
    }
  }).lean();
  titles = titles.filter((title) => {
    return String(title.category.list.user) === String($user._id);
  });
  if ((titles == null ? void 0 : titles.length) < 1) {
    throw createError({
      statusCode: 404,
      statusMessage: "Couldn't find at least one title"
    });
  }
  const titleIds = titles.map((title) => String(title._id));
  await TitleSchema.deleteMany({
    _id: { $in: titleIds }
  });
  createLogs(String($user._id), LogCode.Title.Delete, titles, ({ category, ...title }) => {
    if (!titleIds.includes(String(title._id))) return null;
    return {
      title: new LogObjectId(title._id),
      deletedData: {
        ...title,
        category: new LogObjectId(category == null ? void 0 : category._id)
      }
    };
  });
  return {
    success: true,
    deletedTitles: titleIds
  };
});

export { index_delete as default };
//# sourceMappingURL=index.delete2.mjs.map
