import { l as eventHandler, u as useRuntimeConfig, m as getQuery } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const search_get = eventHandler(async (event) => {
  const config = useRuntimeConfig(event);
  const { type = "multi", text, adult = true, lang = "en-US" } = getQuery(event);
  if (type !== "multi" && type !== "movie" && type !== "tv") return { results: [] };
  const res = await fetch(`${config.tmdbApiUrl}/search/${type}?query=${text}&include_adult=${adult}&language=${lang}&page=1`, {
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${config.tmdbApiKey}`
    },
    method: "GET"
  });
  const json = await res.json();
  json.results = json.results.map((t) => ({ ...t, media_type: (t == null ? void 0 : t.media_type) || type }));
  return json;
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map
