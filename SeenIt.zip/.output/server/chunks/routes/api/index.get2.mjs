import { c as defineEventHandler, U as UserSchema } from '../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_get = defineEventHandler(async (event) => {
  const users = await UserSchema.find().select("-password");
  return users;
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
