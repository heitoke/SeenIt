import { c as defineEventHandler, r as readBody, U as UserSchema, e as createError, f as createLog, j as LogSchema, i as ListSchema, L as LogObjectId } from '../../_/nitro.mjs';
import bcrypt from 'bcryptjs';
import { L as LogCode } from '../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../_/index.mjs';

const index_put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const body = await readBody(event);
  if (body.action === "list:invite") {
    const { host, inviter, invited, list } = body;
    const hostUser = await UserSchema.findOne({ _id: String(invited) }).select("-password").lean();
    if (!hostUser) {
      throw createError({
        statusCode: 404,
        statusMessage: "Not found user!"
      });
    }
    const code = await bcrypt.hash(`${invited}:${inviter == null ? void 0 : inviter._id}:${list == null ? void 0 : list._id}`, 1);
    await createLog(String(invited), LogCode.List.InvitedMember, {
      list,
      inviter,
      host,
      code
    });
    return {
      success: true,
      code,
      inviterId: inviter == null ? void 0 : inviter._id,
      invited: hostUser,
      listId: list == null ? void 0 : list._id
    };
  } else if (body.action === "list:invited") {
    const { userId, code, result } = body;
    const log = await LogSchema.findOne({
      user: String(userId),
      "props.code": String(code)
    });
    if (!log) {
      throw createError({
        statusCode: 404,
        statusMessage: "Not found log by code!"
      });
    }
    log.code = LogCode.List[result === "accept" ? "InviteMemberAccept" : "InviteMemberReject"];
    await log.save();
    console.log(log == null ? void 0 : log.props);
    if (result === "accept") {
      const list = await ListSchema.findOne({ _id: { $in: (_b = (_a = log == null ? void 0 : log.props) == null ? void 0 : _a.list) == null ? void 0 : _b._id } });
      if (!list) {
        throw createError({
          statusCode: 404,
          statusMessage: "Not found list"
        });
      }
      list.members.push({
        user: new LogObjectId(String((_d = (_c = log == null ? void 0 : log.props) == null ? void 0 : _c.invited) == null ? void 0 : _d._id)),
        host: String((_e = log == null ? void 0 : log.props) == null ? void 0 : _e.host),
        permissions: 0
      });
      await list.save();
    }
    return {
      success: true,
      code,
      result
    };
  }
  return createError({
    statusCode: 400,
    data: {
      success: false
    }
  });
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
