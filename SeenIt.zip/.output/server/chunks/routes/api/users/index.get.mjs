import { c as defineEventHandler, U as UserSchema, e as createError } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const userId = (_a = event.context.params) == null ? void 0 : _a.userId;
  try {
    const user = await UserSchema.findOne({
      $or: [
        { _id: userId },
        { username: userId }
      ]
    }).select("-password");
    if (!user) throw createError({
      statusCode: 404,
      statusMessage: "Not found!"
    });
    return user.toJSON();
  } catch (error) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found!"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
