import { c as defineEventHandler, $ as $userAuth, r as readBody, T as TitleSchema, e as createError, h as createLogs, L as LogObjectId } from '../../_/nitro.mjs';
import { L as LogCode } from '../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../_/index.mjs';

const index_put = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const { action, ids, value } = await readBody(event);
  const titles = await TitleSchema.find({
    _id: { $in: ids.map(String) }
  });
  if ((titles == null ? void 0 : titles.length) < 1) {
    throw createError({
      statusCode: 404,
      statusMessage: "Couldn't find at least one title"
    });
  }
  const titleIds = titles.map((title) => String(title._id));
  if (action === "move") {
    await TitleSchema.updateMany({
      _id: { $in: titleIds }
    }, {
      $set: {
        category: String(value)
      }
    }, {
      timestamps: true
    });
    createLogs(String($user._id), LogCode.Title.MoveToCategory, titles, (title) => {
      if (!titleIds.includes(String(title._id))) return null;
      return {
        title: new LogObjectId(title._id),
        from: new LogObjectId(String(title.category)),
        to: new LogObjectId(String(value))
      };
    });
    return { success: true, movedTitles: titleIds };
  } else if (action === "like") {
    await TitleSchema.updateMany({
      _id: { $in: titleIds }
    }, {
      $set: {
        liked: Number(value)
      }
    }, {
      timestamps: true
    });
    createLogs(String($user._id), LogCode.Title.Like, titles, (title) => {
      if (!titleIds.includes(String(title._id))) return null;
      return {
        title: new LogObjectId(title._id),
        from: title.liked,
        to: Number(value)
      };
    });
    return { success: true, likedTitles: titleIds };
  } else if (action === "private") {
    await TitleSchema.updateMany({
      _id: { $in: titleIds }
    }, {
      $set: {
        private: Boolean(value)
      }
    }, {
      timestamps: true
    });
    createLogs(String($user._id), LogCode.Title.Private, titles, (title) => {
      if (!titleIds.includes(String(title._id))) return null;
      return {
        title: new LogObjectId(title._id),
        from: title.private,
        to: Boolean(value)
      };
    });
    return { success: true, privatedTitles: titleIds };
  }
  return { success: false, result: null };
});

export { index_put as default };
//# sourceMappingURL=index.put2.mjs.map
