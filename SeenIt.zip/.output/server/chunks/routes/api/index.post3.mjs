import { c as defineEventHandler, $ as $userAuth, e as createError, u as useRuntimeConfig, r as readBody, C as CategorySchema, k as TMDBTitleSchema, T as TitleSchema } from '../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_post = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  if (!$user) {
    throw createError({
      statusCode: 401,
      statusMessage: "Not auth"
    });
  }
  const config = useRuntimeConfig(event);
  const { categoryId, titles, language = "en-US", liked = 0, rating = 0 } = await readBody(event);
  const category = await CategorySchema.findOne({ _id: String(categoryId) }).populate("list");
  if (!(category == null ? void 0 : category._id)) {
    throw createError({ statusCode: 404, statusMessage: "Not found catgory by id" });
  }
  const list = category.list;
  if (String(list.user) !== String($user == null ? void 0 : $user._id)) {
    throw createError({
      statusCode: 403,
      statusMessage: "You don't have enough rights"
    });
  }
  const listTMDBTitles = await TMDBTitleSchema.find({
    $or: titles.map((title) => ({
      tmdbId: title.id,
      mediaType: title.mediaType === "movie" ? 0 : 1
    }))
  }).lean();
  const listTitles = [];
  for (const { id, mediaType } of titles) {
    let tmdbTitle = listTMDBTitles.find((title2) => Number(title2.tmdbId) === id && Number(title2.mediaType) === (mediaType === "movie" ? 0 : 1));
    if (!(tmdbTitle == null ? void 0 : tmdbTitle._id)) {
      const res = await fetch(`${config.tmdbApiUrl}/${mediaType}/${id}?language=${language}`, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${config.tmdbApiKey}`
        },
        method: "GET"
      });
      const json = await res.json();
      const newTMDBTitle = await new TMDBTitleSchema({
        tmdbId: id,
        mediaType: mediaType === "movie" ? 0 : 1,
        data: json
      });
      await newTMDBTitle.save();
      tmdbTitle = await newTMDBTitle.toObject();
    }
    const newTitle = await new TitleSchema({
      category: String(category._id),
      tmdbTitle: String(tmdbTitle._id),
      liked,
      rating
    });
    await newTitle.save();
    const { category: _c, tmdbTitle: _t, __v, ...title } = newTitle.toObject();
    listTitles.push({
      ...title,
      data: {
        ...tmdbTitle.data,
        mediaType: tmdbTitle.mediaType
      }
    });
  }
  return listTitles;
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
