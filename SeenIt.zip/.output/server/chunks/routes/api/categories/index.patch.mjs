import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, r as readBody, C as CategorySchema, e as createError, f as createLog, L as LogObjectId } from '../../../_/nitro.mjs';
import { L as LogCode } from '../../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../../_/index.mjs';

const index_patch = defineEventHandler(async (event) => {
  var _a;
  const $user = await $userAuth.require(event);
  const categoryId = await getRouterParam(event, "categoryId");
  const { name, private: privateMode } = await readBody(event);
  const category = await CategorySchema.findOne({ _id: String(categoryId) }).populate("list");
  if (!category) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found category by id"
    });
  }
  if (String((_a = category.list) == null ? void 0 : _a.user) !== String($user._id)) {
    throw createError({
      statusCode: 403,
      statusMessage: "You don't have enough rights"
    });
  }
  const from = {
    name: category.name,
    private: category.private
  };
  if (name) category.name = name;
  if (privateMode !== void 0) category.private = privateMode;
  await category.save();
  createLog(String($user._id), LogCode.Category.Update, {
    category: new LogObjectId(categoryId),
    from,
    to: {
      name: category.name,
      private: category.private
    }
  });
  return category.toObject({ depopulate: true });
});

export { index_patch as default };
//# sourceMappingURL=index.patch.mjs.map
