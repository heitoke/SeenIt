import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, e as createError, $ as $userAuth } from '../../../_/nitro.mjs';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const regexUsername = /^(?!.*[_.]{2})[a-zA-Z0-9][a-zA-Z0-9_.]{1,18}[a-zA-Z0-9]$/;
const regexEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const regexPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;
const register_post = defineEventHandler(async (event) => {
  var _a;
  const $config = useRuntimeConfig();
  const { username, email, password } = await readBody(event);
  if (!regexUsername.test(username)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid username"
    });
  }
  if (!regexEmail.test(email)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid email"
    });
  }
  if (!regexPassword.test(password)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Password must be at least 8 characters, contain uppercase, lowercase, digit, and special character"
    });
  }
  const hashed = await bcrypt.hash(password + $config.secret, 10);
  let newUser;
  try {
    newUser = await ((_a = mongoose.connection.db) == null ? void 0 : _a.collection("users").insertOne({ username, email, password: hashed }));
  } catch (error) {
    const isError = !String(error).includes("E11000");
    throw createError({
      statusCode: isError ? 500 : 401,
      statusMessage: isError ? String(error) : "User already registered."
    });
  }
  await $userAuth.set(event, String(newUser == null ? void 0 : newUser.insertedId));
  return {
    registered: true
  };
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
