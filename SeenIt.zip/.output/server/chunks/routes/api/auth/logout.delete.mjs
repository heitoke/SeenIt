import { c as defineEventHandler, $ as $userAuth } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const logout_delete = defineEventHandler(async (event) => {
  return await $userAuth.logOut(event);
});

export { logout_delete as default };
//# sourceMappingURL=logout.delete.mjs.map
