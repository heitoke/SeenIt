import { c as defineEventHandler, $ as $userAuth } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const me_get = defineEventHandler(async (event) => {
  const payload = await $userAuth.require(event);
  return { ...payload };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
