import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, e as createError, $ as $userAuth } from '../../../_/nitro.mjs';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const login_post = defineEventHandler(async (event) => {
  var _a;
  const $config = useRuntimeConfig();
  const { login, password } = await readBody(event);
  if (!login || !password) {
    throw createError({
      statusMessage: "required field"
    });
  }
  const user = await ((_a = mongoose.connection.db) == null ? void 0 : _a.collection("users").findOne({ $or: [{ email: login }, { username: login }] }));
  if (!user) throw createError({
    statusCode: 404,
    statusMessage: "The user by this login does not exist..."
  });
  const matches = await bcrypt.compare(password + $config.secret, user.password);
  if (!matches) throw createError({
    statusCode: 401,
    statusMessage: "login or password is wrong! please try again later"
  });
  await $userAuth.set(event, String(user._id));
  const { password: _, ...loginUser } = user;
  return {
    loggedIn: true,
    user: loginUser
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
