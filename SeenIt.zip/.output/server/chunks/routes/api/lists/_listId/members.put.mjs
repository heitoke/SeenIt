import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, i as ListSchema, e as createError, r as readBody, U as UserSchema, f as createLog } from '../../../../_/nitro.mjs';
import bcrypt from 'bcryptjs';
import { L as LogCode } from '../../../../_/log.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';
import '../../../../_/index.mjs';

const members_put = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const listId = await getRouterParam(event, "listId");
  const list = await ListSchema.findOne({ _id: String(listId) }).select("-__v -members");
  if (!list) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found!"
    });
  }
  const { action, members } = await readBody(event);
  if (action === "invite") {
    const hostUsers = members.filter((m) => m.host === "host");
    if (hostUsers.length > 0) {
      const listHostUsers = hostUsers.length > 0 ? await UserSchema.find({
        _id: { $in: hostUsers.map((m) => String(m.userId)) }
      }).lean() : [];
      for (const user of listHostUsers) {
        const code = await bcrypt.hash(`${$user._id}:${user._id}:${list._id}`, 1);
        await createLog(String($user._id), LogCode.List.InviteMember, {
          list: list.toObject(),
          invited: user,
          code
        });
        await createLog(String(user._id), LogCode.List.InvitedMember, {
          list: list.toObject(),
          inviter: $user,
          code
        });
      }
    }
    const networkUsers = members.filter((m) => m.host !== "host");
    if (networkUsers.length > 0) {
      const hostUrl = event.req.headers["host"];
      for (const { userId, host } of networkUsers) {
        const res = await $fetch(`http://${host}/api/members`, {
          body: JSON.stringify({
            action: "list:invite",
            host: hostUrl,
            inviter: $user,
            invited: userId,
            list
          }),
          method: "PUT"
        });
        if (!(res == null ? void 0 : res.success)) return;
        await createLog(String($user._id), LogCode.List.InviteMember, {
          list: list.toObject(),
          invited: res == null ? void 0 : res.invited,
          host,
          code: res.code
        });
      }
    }
    return { success: true };
  }
  return { success: false, result: null };
});

export { members_put as default };
//# sourceMappingURL=members.put.mjs.map
