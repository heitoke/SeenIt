import { c as defineEventHandler, $ as $userAuth, g as getRouterParam, r as readBody, i as ListSchema } from '../../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_patch = defineEventHandler(async (event) => {
  await $userAuth.require(event);
  const listId = await getRouterParam(event, "listId");
  const { name, private: privateMode } = await readBody(event);
  const result = await ListSchema.findByIdAndUpdate(String(listId), {
    $set: {
      name,
      private: privateMode
    }
  }, {
    new: true
  });
  return result;
});

export { index_patch as default };
//# sourceMappingURL=index.patch.mjs.map
