import { c as defineEventHandler, $ as $userAuth, r as readBody, i as ListSchema } from '../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_post = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const { name } = await readBody(event);
  const newList = await new ListSchema({
    user: $user._id,
    name,
    private: false
  });
  await newList.save();
  return newList;
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
