import { c as defineEventHandler, $ as $userAuth, r as readBody, i as ListSchema, e as createError, C as CategorySchema } from '../../_/nitro.mjs';
import 'mongoose';
import 'jose';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'consola';
import 'consola/utils';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'async_hooks';

const index_post = defineEventHandler(async (event) => {
  const $user = await $userAuth.require(event);
  const { listId, name, private: privateMode = false } = await readBody(event);
  const list = await ListSchema.findOne({ user: $user._id, _id: listId });
  if (!(list == null ? void 0 : list._id)) {
    throw createError({
      statusCode: 404,
      statusMessage: "Not found list!"
    });
  }
  const newCategory = await new CategorySchema({
    list: listId,
    name,
    private: privateMode
  });
  await newCategory.save();
  return newCategory;
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
