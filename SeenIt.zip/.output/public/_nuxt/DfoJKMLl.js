import{_ as e,c,o}from"./hGyOJ3Hn.js";const s={},t={class:"home"};function n(r,_){return o(),c("div",t," Home Page ")}const d=e(s,[["render",n]]);export{d as default};
