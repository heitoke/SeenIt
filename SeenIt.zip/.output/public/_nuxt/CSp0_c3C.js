import{f as e}from"./hGyOJ3Hn.js";const r=e("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);export{r as L};
